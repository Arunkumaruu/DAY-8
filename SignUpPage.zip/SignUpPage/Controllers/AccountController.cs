﻿using Microsoft.AspNetCore.Mvc;
using SignUpPage.Models;
using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Security;

namespace SignUpPage.Controllers
{
    public class AccountController : Controller
    {
        private readonly string connectionString = "Data Source=KUMAR\\SQLEXPRESS;Initial Catalog=signupp;Integrated Security=True;Trusted_Connection=True;TrustServerCertificate=True;";

        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignUp(User user)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("sp_RegisterUser", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@Username", user.Username);
                            cmd.Parameters.AddWithValue("@Password", user.Password);
                            cmd.Parameters.AddWithValue("@Email", user.Email);
                            cmd.Parameters.AddWithValue("@FullName", user.FullName);

                            conn.Open();
                            cmd.ExecuteNonQuery();
                        }
                    }
                    return RedirectToAction("SignUpSuccess");
                }
                catch (SqlException ex)
                {
                    // Handle SQL exceptions (e.g., duplicate entries)
                    ModelState.AddModelError(string.Empty, ex.Message);
                }
                catch (Exception ex)
                {
                    // Handle other exceptions
                    ModelState.AddModelError(string.Empty, "An error occurred while processing your request.");
                }
            }
            return View(user);
        }

        public IActionResult SignUpSuccess()
        {
            return View();
        }
    }
}
